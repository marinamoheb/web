<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title> update</title>
</head>
<body>
<div class="index">
<div class="body">
			<ul>
                <li><a href="#Contact">Contact</a></li>
                <li><a href="#Support">Support</a></li>
                <li><a href="Why US">Why us</a></li>
                <li><a href="#Services">Services</a></li>
                <li><a href="#About Us" >About us</a></li>
                <li><a href="#Home">Home</a></li>
                <li style="float:left; padding: 10px 10px 10px 50px;"><a style="font-size:30px;" href="#U_librarby">UniLibrary</a></li>
            </ul>
        </div>
    
<div class="form">
<form action="" method="post">
  <center>
   <label>update user details<lable> </br>
   <label> User ID</label>
   <input type="text" name="id" placeholder="enter user id "/></br>
   <label>Frist name</label>
   <input type="text" name="fname" placeholder="enter frist name"/></br>
   <label>Last name </label>
   <input type="text" name="lname"placeholder="enter last name"/> </br>
   <label>Username</label>
   <input type="text" name="username"placeholder="enter username"/> </br>
   <label> User Email</label>
   <input type="text" name="email"placeholder="enter email"/></br>
   <label>Password</label>
   <input type="text" name="password"placeholder="enter  password"/></br>
   <input type="submit" name="update" value="update data "/></br>

   </center>
  </form>
  </div>
</div>
</body>
</html>
<?php
$connection=mysqli_connect('127.0.0.1','root','');
$db=mysqli_select_db($connection,'loginsystem');

if(isset($_POST['update']))
{
    $id=$_POST['id'];
    $query="UPDATE users SET uNameUsers='$_POST[username]',emailUsers='$_POST[email]',pwUsers='$_POST[password]' WHERE idUsers='$_POST[id]'";
    $query_run=mysqli_query($connection,$query);
    if($query_run)
    {
    echo'<script type="text/javascript"alert("data updated")</script>';
    }
    else
    {
        echo'<script type="text/javascript"alert("data  not updated")</script>';
    }
}
?> 
